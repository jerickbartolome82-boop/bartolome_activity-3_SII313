# Inventory Management System (C# WinForms + MySQL)

Sign In, Register, Dashboard, Products, Suppliers, Transactions, Reports, Users.
Every table has search, paging (5/10/25/50 rows), and CSV export.

## Setup (MySQL Workbench)
1. Open `schema.sql` in Workbench and run it (lightning bolt). It creates `inventory_db` and all tables.
   - Had the OLD version already? Run `upgrade_existing.sql` once, then run `schema.sql`.
2. OPTIONAL demo data (25 products, 6 suppliers, history) so paging has something to show:
   run `sample_data.sql` ONCE.
3. Put your MySQL password in `connection.txt`:
   `Server=localhost;Port=3306;Database=inventory_db;Uid=root;Pwd=YOURPASSWORD;Connection Timeout=5;`
   (Visual Studio: connection.txt -> Properties -> Copy to Output Directory = Copy always. The .csproj already does this.)
4. Open `InventorySystem.csproj` in Visual Studio 2022 (".NET desktop development" workload), wait for the
   NuGet restore (MySql.Data), press F5.
5. Register an account, then sign in.

Using your own project? Add the `.cs` files and the **MySql.Data** NuGet package (.NET Framework 4.7.2+ or .NET 6/7/8).

## What each screen does
| Screen | What you can do |
|---|---|
| Dashboard | Live counts (total / in stock / low / out of stock / stock value) + searchable product table |
| Products | Add, edit, delete. Filter by status. Stock is set when adding; after that it changes only through Transactions |
| Suppliers | Add, edit, delete. Deleting a supplier keeps its products |
| Transactions | Record Stock In / Stock Out (history is never edited or deleted). Stock Out cannot exceed what is on hand |
| Reports | Reorder list, stock valuation, stock movement summary |
| Users | See accounts, disable / enable / unlock them (you can't disable yourself) |

Status rule: stock = 0 -> Out of Stock; stock <= reorder level -> Low Stock; otherwise In Stock.

## Database
`users` (login) | `suppliers` | `products` (-> supplier) | `transactions` (-> product)
- Duplicate usernames, emails, product names, supplier names are blocked by UNIQUE constraints.
- CHECK constraints stop negative stock and negative prices at the database level too.
- Deleting a product also deletes its transactions (CASCADE); deleting a supplier sets its products' supplier to empty.

## Validation rules
- **Username** 4-30 chars, starts with a letter, letters/numbers/_
- **Password** 8-64 chars, upper + lower + number, no spaces, must not contain the username
- **Email** valid format, saved lowercase
- **Product name** 2-100 | **Category** 2-50 | **Unit price** 0.01-9,999,999.99, max 2 decimals
- **Initial stock** 0-1,000,000 | **Reorder level** 0-100,000 (whole numbers, digits only)
- **Transaction quantity** 1-100,000; Stock Out cannot be more than the stock on hand
- **Supplier** name 2-100; phone (optional) 7-15 digits; email (optional) valid; address (optional) max 200

## Security notes
- Passwords are stored as salted PBKDF2-SHA256 (600,000 iterations), never as text.
- 5 wrong passwords locks the account for 5 minutes (an admin can unlock it on the Users screen).
- All SQL uses parameters. Users only see short, safe error messages.
- CSV export neutralises spreadsheet formulas (cells starting with = + - @).
